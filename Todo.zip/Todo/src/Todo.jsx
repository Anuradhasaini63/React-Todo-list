import React, { useState } from 'react'

const Todo = () => {

    const [tasks, settask] = useState([])
    const [input, setInput] = useState('')

    const addtask = ()=>{
        if(input.trim()){
            settask([...tasks, input.trim()]);
        }
    }
    const deletetask = (index) =>{
        const updateTask = tasks.filter((_, i) => i !== index);
        settask(updateTask);
    }
  return (
    <>
        <div className='bg-blue-950 w-[750px] p-3 mt-5 rounded-sm'>
            <div>
            <input value={input} onChange={(e) => setInput(e.target.value)} type='text' className='p-1 w-[650px] pe-3' placeholder='Enter your task here...' />
            <button onClick={addtask} className='py-1 px-4 bg-slate-400 rounded-sm text-white'>Add</button>
            </div>
            <div className='bg-slate-200 p-3 mt-5 rounded-sm text-left'>
                <ol>
                {tasks.map((task, index)=>(
                    <li key={index} className='mb-3 flex justify-between'>
                     <p>{index +1}. <span className='text-clip overflow-hidden'>{task}</span></p>   
                        <button onClick={() => deletetask(index)} className='h-[40px] py-1 text-black px-4 bg-slate-400 rounded-sm'>Delete</button>
                    </li>
                    ))}
                </ol>
            </div>
        </div>
    </>
  )
}

export default Todo
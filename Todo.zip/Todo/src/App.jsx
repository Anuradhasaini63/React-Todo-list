import { useState } from 'react'
import './App.css'
import Todo from './Todo'
import './output.css'


function App() {

  return (
    <>
        <h1 className='text-blue-950 text-center text-lg font-bold'>Add your task here</h1>
        <Todo />
    </>
  )
}

export default App
